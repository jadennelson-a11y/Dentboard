/* Connects the app's AI calls to the site's own /api/ai endpoint. */
(function(){
var KEY="dentboard_code";
function code(){try{return localStorage.getItem(KEY)||""}catch(e){return""}}
function askCode(msg){return new Promise(function(done){
 var ov=document.createElement("div");ov.style.cssText="position:fixed;inset:0;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;z-index:50;padding:16px";
 var c=document.createElement("div");c.style.cssText="background:var(--card,#fff);color:var(--ink,#111);border:1px solid var(--line,#ddd);border-radius:12px;padding:20px;max-width:380px;width:100%;font:15px/1.5 system-ui,sans-serif";
 var h=document.createElement("b");h.textContent="Access code";var p=document.createElement("p");p.textContent=msg||"This preview is invite-only. Enter the access code you were given to use AI features.";p.style.cssText="color:var(--mute,#666);font-size:13px";
 var i=document.createElement("input");i.type="password";i.placeholder="Access code";i.style.cssText="width:100%;padding:9px 12px;border:1px solid var(--line,#ccc);border-radius:8px;background:var(--bg,#fff);color:inherit;margin-bottom:12px";
 var r=document.createElement("div");r.style.cssText="display:flex;gap:8px;justify-content:flex-end";
 function mk(t,pri){var b=document.createElement("button");b.textContent=t;b.style.cssText="padding:8px 14px;border-radius:8px;border:1px solid var(--acc,#0b6b68);cursor:pointer;"+(pri?"background:var(--acc,#0b6b68);color:#fff;font-weight:600":"background:transparent;color:inherit;border-color:var(--line,#ccc)");return b}
 var ok=mk("Continue",1),no=mk("Cancel");function close(v){ov.remove();done(v)}
 ok.onclick=function(){try{localStorage.setItem(KEY,i.value.trim())}catch(e){}close(true)};no.onclick=function(){close(false)};i.onkeydown=function(e){if(e.key==="Enter")ok.click()};
 r.appendChild(no);r.appendChild(ok);c.appendChild(h);c.appendChild(p);c.appendChild(i);c.appendChild(r);ov.appendChild(c);document.body.appendChild(ov);i.focus()})}
async function call(body,tried){
 var r=await fetch("api/ai",{method:"POST",headers:{"Content-Type":"application/json","x-access-code":code()},body:JSON.stringify(body)});
 if(r.status===401){if(tried){var e1=new Error("code");e1.code="code";throw e1}var ok=await askCode(code()?"That code didn’t work. Please try again.":"");if(!ok){var e2=new Error("code");e2.code="code";throw e2}return call(body,true)}
 if(!r.ok){var e=new Error("ai "+r.status);e.code=r.status===429?"rate_limited":"error";throw e}
 return r.json()}
function parse(t){t=String(t).replace(/```json|```/g,"");var i=t.indexOf("{"),j=t.lastIndexOf("}");return JSON.parse(t.slice(i,j+1))}
var sm=async function(prompt,o){o=o||{};var d=await call({prompt:prompt,web:!!o.web,tier:"smart"});if(o.onText)o.onText({text:d.text});return{text:d.text}};
sm.json=async function(prompt){for(var t=0;t<2;t++){var d=await call({prompt:prompt+"\n\nReturn only valid JSON.",tier:"fast"});try{return parse(d.text)}catch(e){}}throw new Error("json")};
window.claude={use:async function(){return sm}};
})();
